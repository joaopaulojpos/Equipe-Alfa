<?php require_once ?>

<body>
	<div>  

		<fieldset>
			<form method="POST" action="../model/cadastroDisciplina.php">
			  <label for="nomeDisciplina" class="label">Nome: </label><input type="text" id="nomeDisciplina" name="nomeDisciplina" required maxlength="20"/>
			  <br/><br/><br/>	
	     	  <input type="submit" value="Cadastrar" class="btao"/>
	      	  <input type="button" value="Listar" onclick="location.href = '../model/listarDisciplina.php'" class="btao"/>
	          <input type="button" value="Voltar" onclick="location.href = '../view/inicioAdministrador.html'" class="btao"/>
			</form>
		</fieldset>

	</div>
</body>
</html>

