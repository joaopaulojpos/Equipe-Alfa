<?php

header('Location:view/login.html');
