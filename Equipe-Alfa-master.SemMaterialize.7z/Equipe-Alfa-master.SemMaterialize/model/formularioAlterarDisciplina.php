<!DOCTYPE html>
<html lang="pt-br">

<head>
 		<meta charset="utf-8">
        <title>Cadastro Disciplina</title>
        <link rel="stylesheet" href="../css/tela.css">	
</head>

<body>

<?php 

	require_once 'conexao.php';
	
	$nomeDisciplina= $_GET['nomeDisciplina'];
	$codigo= $_GET['codigo'];


	$sql="SELECT * FROM disciplina WHERE id = '$codigo'  ";
	$query = mysqli_query($conn, $sql) or die("Falha no BD: " . mysqli_error($conn));


	$row= mysqli_fetch_assoc($query);//pega os dados completo.

?>
<div>  

		<fieldset>
			<form method="POST" action="../model/alterarDisciplina.php?codigo=<?php echo $row['id'];?>">
			<!--no campo quando alterarmos ele vai passar um novo valor para alterar. mas como comparar ele com o antigo?-->
			
			  <label for="nomeDisciplina" class="label">Nome: </label><input type="text" id="nomeDisciplina" name="nomeDisciplina" 
			  value="<?php echo $nomeDisciplina?>" required maxlength="20"/>
			 
			  <br/><br/><br/>
			 
	     	  <input type="submit" value="Alterar" class="btao"/>	      	  
	          <input type="button" value="Inicio" onclick="location.href = '../view/inicioAdministrador.html'" class="btao"/>
	           <input type="button" value="Listar" onclick="location.href = 'listarDisciplina.php'" class="btao"/>	
			</form>
		</fieldset>

	</div>
</body>
</html>