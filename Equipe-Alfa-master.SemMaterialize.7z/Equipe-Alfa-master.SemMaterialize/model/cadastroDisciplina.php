<?php
	
		require_once 'conexao.php';

		$nomeDisciplina = $_POST['nomeDisciplina'];
		
		$sql = "INSERT INTO disciplina(NOMEDISCIPLINA) values ('$nomeDisciplina')";		
		mysqli_query($conn,$sql) or die("Erro ao inserir os dados. Erro: ".mysqli_error($conn));
		
		echo " <script type='text/javascript'>alert('Seu cadastro foi realizado com sucesso!');location.href='../view/CadastroDisciplina.html';</script>";
		//echo "  <script type='text/javascript'>alert('Dados do aluno excluídos com sucesso!');location.href='listarAluno.php';</script>";

		mysqli_close($conn);

	?>
