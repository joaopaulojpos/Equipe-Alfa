
<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<title>Inserir Disciplina</title>
</head>

<body>
<form method="POST" action = "cadastroTurma.php">
	Codigo<br/>
	<input type = "text" id="codigoturma" name= "codigoturma"/><br/><br/>
	Ano<br/>
	<input type = "text" id="ano" name= "ano"/><br/><br/>
	Turno<br/>
	<input type = "text" id="turno" name= "turno"/><br/><br/>
	Periodo<br/>
	<input type = "text" id="codigoperiodo" name= "codigoperiodo"/><br/><br/>
	
	<input type = "submit" value="Inserir"/>

</body>

</html>