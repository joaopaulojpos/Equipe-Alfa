<!DOCTYPE html>
<html>
    <head lang="pt-br">
        <meta charset="utf-8">
        <title>Disciplinas</title>
        <link rel="stylesheet" href="../css/tela.css">
    </head>
    <body>

        <?php
        
        require_once 'conexao.php';

        if (isset($_POST['nomeDisciplina'])) {

            $nomeDisciplina = $_POST['nomeDisciplina'];
          
               
                $sql = "SELECT * FROM disciplina WHERE  NOMEDISCIPLINA = '$nomeDisciplina'";
                $query = mysqli_query($conn, $sql) or die("Erro ao buscar a disciplina. Erro: " . mysqli_error($conn));


                echo "<fieldset>";
                while ($row = mysqli_fetch_assoc($query)) {

                    echo "<h2><b>Resultado da Pesquisa</b></h2>";
                    echo "<hr>";
                    echo "<label><b>Nome: </b></label> " . $row['NOMEDISCIPLINA'] . " ";
                   
                    echo "<br/><br/>";


        ?>          
                    <div id='links'><a href="excluirDisciplina.php?nomeDisciplina=<?php echo $row['NOMEDISCIPLINA']; ?>"
                    id='linkexcluir'><input title="Excluir" type="image" src="../imagem/lixeira1.png" width="25" height="25" id="icone"></a><!-- ABAIXO PASSO POR GET O NOME EO ID-->
                    <a href="formularioAlterarDisciplina.php?nomeDisciplina=<?php echo $row['NOMEDISCIPLINA']; ?>&codigo=<?php echo $row['id']; ?>"
                    id='linkeditar'><input title="Alterar" type="image" src="../imagem/editar.png" width="25" height="25" id="icone"></a></div>


        <?php

                }
                echo "<a href='listarDisciplina.php'><input type='button' value='Voltar' class='botao'></a>";
                echo "</fieldset>";
        } else {
            //LISTANDO AS DISCIPLINAS
            $sql = "SELECT * FROM disciplina";
            $query = mysqli_query($conn, $sql) or die("Não foi possível listar os dados.\n Erro: " . mysql_error($conn));

            if (mysqli_num_rows($query) > 0) {

                echo "<fieldset>";
                echo "<h2><b>Lista das disciplinas</b></h2>";
                echo "<hr>";
                echo "<br/><br/>";
                echo "<div id='divscrowbar'>";

                while ($row = mysqli_fetch_assoc($query)) {

                    echo "<div><label><b>Nome: </b></label> " . $row['NOMEDISCIPLINA'] . " " . "</div>";
        ?>	
                    <!--Enviando a matrícula por método GET para EXCLUIR e EDITAR os dados do aluno-->
                    <div id='links'><a href="excluirDisciplina.php?id=<?php echo $row['id']; ?>"
                     id='linkexcluir'><input title="Excluir"type="image" src="../imagem/lixeira1.png" width="25" height="25" id="icone"></a>&nbsp<!-- ABAIXO PASSO POR GET O NOME EO ID-->
                    <a href="formularioAlterarDisciplina.php?nomeDisciplina=<?php echo $row['NOMEDISCIPLINA']; ?>&codigo=<?php echo $row['id'];?>" 
                    id='linkeditar'><input title="Alterar" type="image" src="../imagem/editar.png" width="25" height="25" id="icone"></a></div>	

                    <?php
                    echo "<hr><br/>";
                }
                echo "</div>";
                echo "<br/><br/>";
                echo "<a href='listarDisciplina.php'><input type='button' value='Atualizar' class='botao'/></a>" . " ";
                echo "<a href='../view/cadastroDisciplina.html'><input type='button' value='Novo cadastro' class='btNovoCad'/></a>";
                echo"</fieldset>";

                mysqli_close($conn);
            } else {

                echo "<script type='text/javascript'>alert('Não há registro a serem listados!');location.href='../view/cadastroDisciplina.html';</script>";
            }
        }
        ?>
        <div>
            <fieldset>
                <h2><b>Buscar Disciplinas</b></h2>
                <hr>
                <form method="post" action="">
                    <label for="nomeDisciplina"><b>Nome:</b> </label><input type="text" id="nomeDisciplina" name="nomeDisciplina"/>
                    <input type="submit" value="Buscar" class="botao">		
                </form>
            </fieldset>
        </div>
    </body>
    <!--//http://localhost:83/Hugo/Equipe-Alfa-master/view/CadastroDisciplina.html-->
</html>

