<?php

require_once 'conexao.php';

if (isset($_POST['nomeDisciplina'])) {

	$cod= $_GET['codigo'];
    $nomeDisciplina = $_POST['nomeDisciplina'];

   
   
    $sql = "UPDATE disciplina SET NOMEDISCIPLINA = '$nomeDisciplina' WHERE id ='$cod'";
    $query = mysqli_query($conn, $sql) 
    or die("Falha ao atualizar dados da disciplina: " . mysqli_error($conn));


echo  $sql;

	mysqli_close($conn);
    header("Location: listarDisciplina.php");

    //retirei o javaScript e já redirecionei direto.  :)  ^_^  :p 


    
}
?>
